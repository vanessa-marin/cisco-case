# Pitch – Cisco – Plataforma B2B Técnica (ES)
Pitch de 60–90 segundos en español.
