# Case Summary – Cisco – Plataforma B2B Técnica (ES)
Resumen ejecutivo del caso en español.
