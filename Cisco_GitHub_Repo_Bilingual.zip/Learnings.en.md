# Learnings – Cisco – Plataforma B2B Técnica (EN)
Key learnings from the project in English.
