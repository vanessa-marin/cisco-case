# Product Case – Cisco – Plataforma B2B Técnica (EN)
Full case description in English. Herramienta B2B con flujos técnicos y configuraciones complejas para clientes enterprise.
