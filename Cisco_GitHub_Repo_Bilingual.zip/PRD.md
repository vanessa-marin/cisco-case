# PRD – Cisco – Plataforma B2B Técnica (ES)
Requerimientos funcionales y no funcionales en español.
