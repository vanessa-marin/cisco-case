# Metrics – Cisco – Plataforma B2B Técnica (ES)
Métricas clave, NSM y KPIs definidos para el producto.
