# Architecture Overview – Cisco – Plataforma B2B Técnica (EN)
Functional and architecture overview (EN).
