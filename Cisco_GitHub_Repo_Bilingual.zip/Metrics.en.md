# Metrics – Cisco – Plataforma B2B Técnica (EN)
North Star Metric and key KPIs for the product.
