# Architecture Overview – Cisco – Plataforma B2B Técnica (ES)
Descripción funcional y de arquitectura (ES).
