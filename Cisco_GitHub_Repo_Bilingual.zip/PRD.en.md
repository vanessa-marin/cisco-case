# PRD – Cisco – Plataforma B2B Técnica (EN)
Functional and non-functional requirements in English.
