# Cisco – Plataforma B2B Técnica – Product Case (EN)

This repository contains the full case in English and Spanish.
