# Learnings – Cisco – Plataforma B2B Técnica (ES)
Aprendizajes clave del proyecto en español.
