# Pitch – Cisco – Plataforma B2B Técnica (EN)
60–90 seconds pitch in English.
