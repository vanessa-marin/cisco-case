# Case Summary – Cisco – Plataforma B2B Técnica (EN)
Executive summary of the case in English.
